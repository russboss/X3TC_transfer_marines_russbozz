Basic Instructions for all who have never used a script before

transfer marines
adds the ability to transfer marines from a TP to any other ship (under Piracy Menu)


Q: how is transfer Marines useful
A: alright for starters I'll give you a situation
imagine an M6 doing a boarding operation on some ship, b/c you ship is an M6 there is a limit of 5 marines at a time but you have a TP full of Marines a sector over..
use Transfer marines
the TP will fly to your approximate location and using it's required teleporter transfer the spare marines to you when you have space when it is empty it'll follow its secondary command that you gave it when you started the command

good thing is you can make chains of TPs in this manner transfering marines to the next in line all the way to you...

Q: what if one ship in a string is destroyed
A: as long as only one ship is destroyed at a time the chain will fill the gap in a short time within 5 seconds

1---2---3 if ship 1 is the head of the line and ship 2 is destroyed 

1---3 ship 3 will start transfers to ship 1 automatically


drop files into corresponding folders

scripts folder:

setup.russbozz.transfer.marine
plugin.russbozz.transfer.marine

t folder:

9314-L044.xml





The Dry Stuff:

As for EULA:
Ha! a What!? use et as you wish, if you can build one better off of my code or had a few tweeks for better proformance go right ahead do it.  Use it in whatever you want.

Give credit where credit is due
~Yup don't care if you list my name on something or not; just don't blatantly claim it as your own.

-Russbozz